/*!
	Function that takes your NAME
*/
const char* getenv_var();
/*!
	Print function, that displayes your NAME
*/
void printenv_var();
